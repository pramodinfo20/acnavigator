
function Warn() {
               alert ("This is a warning message!");
               document.write ("This is a warning message!");
            }
